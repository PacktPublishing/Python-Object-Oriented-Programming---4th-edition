
## Logical View, Vesion Two 

Looking at the context diagram again, processing starts with training data.
Then processing moves on to testing various parameter settings. After that,
samples can be classified.

![Logical View 2](Classifier_1-Logical View 3.png)

In this diagram, we've added the results of each tuning experiment. When the botanist tests the classifier to see how well it classifies, this will
create a `Tuning` object that records the tuning parameters and how well the model matched the real-world test data.

This diagram also shows the `Sample` class being extended via inheritance. 
The other class, `KnownSample` is connected by an open triangle labeled with "Extends."
This depicts a relationship between `Sample` objects and a subclass of `Sample` objects called `KnownSample`.

The subclass, `KnownSample`, inherits all of the attributes and methods of the parent class, `Sample`. 
The subclass introduces two new features: an additional attribute, `species` and an additional method, `matches()`. 
For training and test data, all of the species information is known, so we'll use this subclass of `Sample`
to describe the data we're working with.

When a user makes a request for classification, there's no known species information. This is described
by the `Sample` class. 
The `classify()` method of the `Sample` class will apply the classifier based on the training data and a particular `Tuning` parameter to find
the _k_ nearest neighbors, take a vote, and respond with the nearest species name.

This diagram seems to include the data appropriate for testing of the classifier.
It also seems include data for user requests made to the classifier. 
This view seems to be a much better fit with the use cases.

Also, note that we've switched to filled diamonds to show that all of the relationships should
be understood as proper composition: if we remove a `Training Data` object, **all** of the parts of the
composition should also be removed. Python's built-in claim, characterized by UML aggregation, and
shown with an open diamond, this is a stronger claim. We don't want to permit `Sample` objects or
`Tuning` objects to be have an independent existence.

We have one more tiny consideration here. When we look at the `classify()` method of a `Sample` object,
it needs a specific `Tuning` object. We *could* try to simplify this to providing only a _k_ value,
but this is a bad practice. We shouldn't expose the internal structure of other classes of objects; we should 
honor the class encapsulation.

We'll consider this relationship next, to be sure we've got a reasonably complete logical view.
