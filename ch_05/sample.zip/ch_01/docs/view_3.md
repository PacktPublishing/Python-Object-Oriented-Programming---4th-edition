
## Logical View, Version Three

The `classify()` method of a `Sample` object needs access to a `Tuning` object. 
It turns out these "tuning" parameters are more commonly known as hyperparameters.
We'll need to change terminology.

There are  several choices for providing an appropriate `Tuning` (or `Hyperparameter`) instance to
the `classify()` function:

1.  In the original Logical View diagrams, the `Tuning` object was a parameter to `Sample.classify()`. 
    This is certainly simple, and allows the flexibility to
    use a non-optimal tuning for testing and comparison purposes.
        
2.  We can consider refactoring the `classify` method into a new `Hyperparameter` class.

This second choice can -- perhaps -- lead to a slight simplification. Here's the diagram.

![Logical View 3](Classifier_1-Logical View 3.png)

This diagram pushes the classification away from the `TrainingData` class of objects.
In this revision, the classification process is defined to be part of the `Hyperparameter` class. 
The idea here is to implement the classification of an unknown `Sample` with a process
like the following.

1.  Provide the `Sample` to a specific `Hyperparameter` object. 
    Usually, this is the `Hyperparameter` instance with the highest quality after testing.
    
2.  Each `Hyperparameter` object is associated with a specific `Training Data` object. 
    This `Hyperparameter` object computes the _k_ nearest neighbors. 
    The value of _k_ is an attribute of the `Hyperparameter`  instance.
    
3.  The result, after voting, is a new `KnownSample` object with the species attribute
    filled in. This is a copy of the data from the original `Sample`. The original `Sample`
    can be gracefully ignored at this point, and cleaned up by Python's ordinary garbage collection.
    
These three steps are the implementation of the `Hyperparameter.classify()` method.

The `Hyperparameter.matches()` method evaluates the `Hyperparameter.classify()` method on a `KnownSample`.
The quality score can be as simple as the count of successful matches (assuming a constant sized test set.)
