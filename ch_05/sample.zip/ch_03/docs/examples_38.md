# Python 3 Object-Oriented Programming 4th ed.

Chapter 3, Examples from the text.

## Extending built-ins


```python
Examples for Python < 3.9
>>> from typing import List
>>> CL_1 = List["Contact"]
>>> type(CL_1)
<class 'typing._GenericAlias'>

>>> CL_2 = list["Contact"]
Traceback (most recent call last):
...
TypeError: 'type' object is not subscriptable

```
