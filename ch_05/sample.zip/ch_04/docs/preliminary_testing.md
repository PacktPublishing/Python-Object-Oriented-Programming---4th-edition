# Testing the app

This is part of Chapter 13, 
as well as part of Chapter 4.

The Flask framework provides a useful test client. This lets
us prepare requests and examine responses.  

Here's part of the tests for `User` and `Users`.
This uses **pytest** and the `tmp_path` fixture.
The fixture assigns a temporary path for the
test case, making sure any test files  are isolated
from all other files in the project.

```python
    def test_users(tmp_path):
        with classifier.app.app_context():
            user_file = tmp_path / "users.csv"
            classifier.app.config['TESTING'] = True
            classifier.app.config['USER_FILE'] = user_file
    
            seed_users = classifier.Users()
            seed_users.init_app(current_app)
```

This shows a very import requirement for testing
Flask applications. Almost everything in Flask
requires an "application context". This is created
by invoking the `app_context()` method of
an application. Within this context, `Flask` features
work as if the application is working normally.

For the test, we created an instance of the `Users`
class, named `seed_users`. This object's `init_app()`
method binds it to the current application.

We can then add `User` objects and save the resulting document.
This creates a test fixture.

```python
    noriko = User(
        username='noriko',
        email='noriko@example.com',
        real_name='Noriko K. L.',
        role=Role.BOTANIST,
        password='md5$H5W30kno$10a2327b2fce08c1ad0f65a12d40552f'
    )
    seed_users.add_user(noriko)
```

We can then create yet another `Users` object,
load the file, and confirm that it behaves as needed.

```python
    users = classifier.Users()
    users.init_app(current_app)
    assert users.get_user("noriko") == noriko
    assert users.get_user("noriko").valid_password("Hunter2")
```

We used `get_user()` to retrieve a specific user
and compared the result fetched from the `Users` collection
to the expected result. Since we defined an `__eq__()`
method, we can use a simple `==` test here.

We also test the `valid_password()` method
to see if the seeded password really does match the 
expected password.

We'ved used the relatively insecure MD5 hashes here because
they're short. A practical application will likely use
the default hashing method.
For version 1.0.1 of werkzeug, it's `pbkdf2:sha256:150000`.
These, however, are very long.

If all the assertions are true, then the file 
was loaded, and the user password validation
worked.

## Testing a View Function

Our first view function, the health check,
can be tested using a browser.  This doesn't work out wonderfully well
for testing RESTful API's because it's difficult to force a browser
to include the necessary `Authorization` header.

Additionally, many RESTful API's need a specialized
`Accept` header. And, of course, the input documents
need to be encoded in JSON, something a browser doesn't
do very well.

Some people use tools like Postman to create proper API
requests. In Chapter Thirteen, we'll look deeply at testing,
but for now, we'll start with a quick manual test
to be sure things works.

We can also use programs like **wget** and **curl**
to interact with a RESTful API. These work out pretty
well for performing an "integration" test where the
web application is started and runs normally.

This requires opening two command-line windows.
In IDE tools like PyCharm, we can open multiple terminal
windows by clicking the Terminal tab on the bottom of
the window. 

![bottom-left](bottom-left-corner.png)

This opens a terminal window with a title
of "Local". Next to the title, there's a "+" to add
a new session to the terminal windows. 

![windows](terminal-windows.png)

I like to name one window "Client"
and one window "Server" to make it easy to see what's going
on.

To start a flask application we'll set two environment
variables. For Mac OS X and Linux, it looks like this:

```shell
    export PYTHONPATH=src
    export FLASK_APP=classifier.py
    export FLASK_ENV=development
    flask run
```

For Windows, use `set` instead of `export`.

Here's what we see in  server window.

```shell
    (CaseStudy) slott@MacBookProSLott ch_04 % export PYTHONPATH=src
    (CaseStudy) slott@MacBookProSLott ch_04 % export FLASK_APP=classifier.py
    (CaseStudy) slott@MacBookProSLott ch_04 % export FLASK_ENV=development
    (CaseStudy) slott@MacBookProSLott ch_04 % flask run
     * Serving Flask app "classifier.py" (lazy loading)
     * Environment: development
     * Debug mode: on
     * Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)
     * Restarting with stat
     * Debugger is active!
     * Debugger PIN: 809-602-997
```

The `(CaseStudy)` part of the prompt shows which
Conda environment I'm using. 

The `ch_04` is the working directory. This directory
has several sub-directories.

-   `src` has the application components, classifier.py and model.py

-   `tests` has test cases.

-   `docs` has the documentation.

We set the `PYTHONPATH` environment variable to `src` to put our working code onto
the search path Python uses to resolve module names.
An alternative is to provide a `setup.py` and fully
install the module into Python's site-packages.
For testing, this seems like too much overhead.

The startup messages from Flask all have a `*` to make
them easy to find in a long, complex log.
The most important line is this:

     * Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)

That provides the local URL we can use to interact
with the server.

To make a request to a specific view function,
we append our view function's route to the
base URL shown in the log.

When we switch to the client window, we can run
**curl** (or **wget**) to interact with the server.
(If you don't have curl or wget, you can download
binaries from here: https://curl.haxx.se/download.html)

Here's the **curl** output.
    
```shell    
    (CaseStudy) slott@MacBookPro-SLott CaseStudy % curl http://127.0.0.1:5000/health
    {
      "status": "OK", 
      "user_count": 2, 
      "users": [
        {
          "email": "noriko@example.com", 
          "password": "pbkdf2:sha256:150000$BN8cEAws$c67e695964f0222d3b136c1796e8d7b48e5d489dfa5f242d797ecd9362e78916", 
          "real_name": "Noriko K. L.", 
          "role": "botanist", 
          "username": "noriko"
        }, 
        {
          "email": "emma@example.com", 
          "password": "pbkdf2:sha256:150000$s9Ev2Lqk$b1d90662e0784cfbe2ef1fbe4407cf2ae346e47845d0ad5c680b6dad889ae8c0", 
          "real_name": "Emma K.", 
          "role": "researcher", 
          "username": "emma"
        }
      ]
    }
    (CaseStudy) slott@MacBookPro-SLott CaseStudy % 
```

Here's the extra output that appeared in the server window

    127.0.0.1 - - [11/Oct/2020 08:11:13] "GET / HTTP/1.1" 404 -
    127.0.0.1 - - [11/Oct/2020 08:11:19] "GET / HTTP/1.1" 404 -
    127.0.0.1 - - [11/Oct/2020 08:11:35] "GET /health HTTP/1.1" 200 -

What's important about **curl** is we can provide
specific headers without too much work. The `-u`
option, for example, adds the `Authorization` header.

This lets us create an authorized view function and 
make sure it works.


## More testing with curl


Here's are two client requests using `curl -v` to show
the error status code.
    
```shell
    (CaseStudy) slott@MacBookPro-SLott CaseStudy % curl -v http://127.0.0.1:5000/whoami -u 'noriko:Hunter2' 
    *   Trying 127.0.0.1...
    * TCP_NODELAY set
    * Connected to 127.0.0.1 (127.0.0.1) port 5000 (#0)
    * Server auth using Basic with user 'noriko'
    > GET /whoami HTTP/1.1
    > Host: 127.0.0.1:5000
    > Authorization: Basic bm9yaWtvOkh1bnRlcjI=
    > User-Agent: curl/7.64.1
    > Accept: */*
    > 
    * HTTP 1.0, assume close after body
    < HTTP/1.0 200 OK
    < Content-Type: application/json
    < Content-Length: 274
    < Server: Werkzeug/1.0.1 Python/3.8.5
    < Date: Sun, 11 Oct 2020 12:39:24 GMT
    < 
    {
      "status": "OK", 
      "user": {
        "email": "noriko@example.com", 
        "password": "pbkdf2:sha256:150000$BN8cEAws$c67e695964f0222d3b136c1796e8d7b48e5d489dfa5f242d797ecd9362e78916", 
        "real_name": "Noriko K. L.", 
        "role": "botanist", 
        "username": "noriko"
      }
    }
    * Closing connection 0
    (CaseStudy) slott@MacBookPro-SLott CaseStudy % curl -v http://127.0.0.1:5000/whoami                     
    *   Trying 127.0.0.1...
    * TCP_NODELAY set
    * Connected to 127.0.0.1 (127.0.0.1) port 5000 (#0)
    > GET /whoami HTTP/1.1
    > Host: 127.0.0.1:5000
    > User-Agent: curl/7.64.1
    > Accept: */*
    > 
    * HTTP 1.0, assume close after body
    < HTTP/1.0 401 UNAUTHORIZED
    < Content-Type: application/json
    < Content-Length: 32
    < Server: Werkzeug/1.0.1 Python/3.8.5
    < Date: Sun, 11 Oct 2020 12:42:51 GMT
    < 
    {
      "message": "Unknown User"
    }
    * Closing connection 0
```
